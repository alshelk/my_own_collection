Nginx
=========

This role install nginx with default options

Example Playbook
----------------


    - name: nginx role 
      hosts: servers
      roles:
        - role: nginx



License
-------

MIT

Author Information
------------------

Aleksey Shelkovin
